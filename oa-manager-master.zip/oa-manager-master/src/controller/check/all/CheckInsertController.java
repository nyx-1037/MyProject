package controller.check.all;

import bean.Check;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import service.CheckService;
import service.impl.CheckServiceImpl;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * 打卡接口
 *
 *   负责人:
 *   功能:
 *       接收前端发送过来的数据
 *   请求参数:
 *       account:
 *          表示打卡的用户账号
 *       name:
 *          打卡的用户昵称
 *   响应:
 *       1: 打卡成功
 *       0：打卡失败
 *
 * */
@WebServlet("/checkInsert")
public class CheckInsertController extends HttpServlet {
    // 创建 CheckService 对象
    // 使用 final 关键字，确保 checkService 不会被重新赋值
    private final CheckService checkService = new CheckServiceImpl();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
        // 使用 BufferedReader 读取请求正文
        StringBuilder jsonDataBuilder = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                jsonDataBuilder.append(line);
            }
        }

        // 解析 JSON 数据，提取 account 和 name
        JSONObject jsonObject = JSON.parseObject(jsonDataBuilder.toString());
        String account = jsonObject.getString("account");
        String name = jsonObject.getString("name");

        try {
            // 调用 CheckService 的方法完成打卡操作，传入解析出的参数
            checkService.checkIn(account, name);

            //返回成功状态码并添加响应内容类型
            resp.setStatus(HttpServletResponse.SC_OK);
            resp.setContentType("application/json");
            resp.getWriter().write("{\"message\":\"Check-in successful\"}");
        } catch (Exception e) {
            // 处理服务层抛出的异常
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.setContentType("application/json");
            resp.getWriter().write("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setCharacterEncoding("utf-8");
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        String account = req.getParameter("account");
        String name = req.getParameter("name");

        Check check1 = checkService.checkIn(account, name);

        if (check1 != null) {
            out.print(1);
        }else{
            out.print(0);
        }

        out.flush();
        //返回错误状态码和响应信息
        resp.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        resp.setContentType("text/plain");
        resp.getWriter().write("GET method is not supported for /checkInsert endpoint.");
    }
}
