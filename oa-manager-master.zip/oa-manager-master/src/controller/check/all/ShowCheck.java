package controller.check.all;


import service.CheckService;
import service.impl.CheckServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/showCheck")
public class ShowCheck extends HttpServlet {
    /**
     *   负责人:
     *   功能:
     *       根据用户信息 展示对应的打卡情况
     *       注意 响应数据通过调用service来获取
     *   请求参数:
     *       account:
     *          表示查询的用户账号
     *       type:
     *          0: 按周查询
     *          1: 按月查询
     *          2: 按年查询
     *       val:
     *          如果按周查询 值是1~5 表示当月第几周 (周一在几月就算是那个月的 比如2.28是周一 那么3月1周是3.6~3.11)
     *          如果按月查询 值是1~12 表示今年第几月
     *          如果按年查询 值是2000~2024 表示哪年
     *   响应:
     *       json串
     *      type0的情况:

            {
                [{date: '周一', time: '08:02', statu: '迟到'},
                  {date: '周二', time: '07:52', statu: '正常'},
                  {date: '周三', time: '', statu: '请假'}]
            }
            type1的情况:
                 {
                    [{week: 3, check: 5, data: 7},{....}] //本月第几周, 实际打卡次数, 应打卡次数
                }
            type2的情况:
                 {
                    [{month: 3, check: 28, data: 31, statu: '未全勤'},{....}]    //第几月, 实际打卡次数, 应打卡次数, 是否全勤
                 }
     *
     * */

    CheckService checkService = new CheckServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setCharacterEncoding("utf-8");
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        String account = req.getParameter("account");
        int type = Integer.parseInt(req.getParameter("type"));
        int val = Integer.parseInt(req.getParameter("val"));

        String s = "";

        if (type == 0) {
            s = checkService.getCheckByWeek(account,val);
        }else if (type == 1) {
            s = checkService.getCheckByMonth(account,val);
        }else if (type == 2) {
            s = checkService.getCheckByYear(account,val);
        }

        out.print(s);
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
