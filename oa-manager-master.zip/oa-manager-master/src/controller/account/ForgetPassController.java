package controller.account;

import bean.User;
import com.google.gson.Gson;
import service.impl.AccountServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/forgetPass")
public class ForgetPassController extends HttpServlet {
    /**
     *   负责人:
     *   功能:
     *       传入用户账号, 邮箱和新密码
     *          account, password, email
     *       如果账号和邮箱对应 将用户密码设为新密码 进入登录界面
     *       如果账号和邮箱对应 返回忘记密码界面 提示信息错误
     *   请求参数:
     *       account: string 账号
     *       password: string 密码
     *       email: string 邮箱
     *   响应:
     *       如果账号和邮箱对应 将用户密码设为新密码 进入登录界面
     *       如果账号和邮箱对应 返回忘记密码界面 提示信息错误
     *
     * */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获得账号、密码、邮箱
        String account = req.getParameter("account");
        String password = req.getParameter("password");
        String email = req.getParameter("email");
        //获得服务类接口
        AccountServiceImpl accountService = new AccountServiceImpl();
        //调用接口实现忘记密码，如果成功则返回更新后的用户类，否则返回null
        User user = accountService.forgetPass(account, password, email);
        //设置回应格式,返回Json数据
        resp.setContentType("application/json");
        //设置编码格式
        resp.setCharacterEncoding("UTF-8");
        //使用Gson库将对象转换为json字符串
        Gson gson = new Gson();
        //构建响应数据
        //将登录成功的用户的对象转成json数据返回给前端
        String data = gson.toJson(user);
        //数据返回前端
        resp.getWriter().write(data);
    }
}
