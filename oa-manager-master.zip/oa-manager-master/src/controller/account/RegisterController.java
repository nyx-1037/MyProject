package controller.account;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import bean.User;
import com.google.gson.Gson;
import service.impl.AccountServiceImpl;

@WebServlet("/register")
public class RegisterController extends HttpServlet {
    /**
     *   负责人:
     *   功能:
     *       传入用户基本数据
     *          name, account, password, email
     *       如果账号重复 回到注册界面 并且额外写一个提示"账号已存在"  (具体格式和负责界面的同学沟通)
     *       如果账号注册成功 进入登录界面
     *   请求参数:
     *       name: string 用户昵称
     *       account: string 账号
     *       password: string 密码
     *       email: string 邮箱
     *   响应:
     *       如果账号重复 回到注册界面 并且额外写一个提示"账号已存在"  (具体格式和负责界面的同学沟通)
     *       如果账号注册成功 进入登录界面
     *
     * */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        //创建新用户对象
        User user = new User();
        //设置用户各类属性
        user.setName(req.getParameter("name"));
        user.setPassword(req.getParameter("password"));
        user.setEmail(req.getParameter("email"));
        user.setAccount(req.getParameter("account"));
        //调用接口新增用户
        AccountServiceImpl accountService = new AccountServiceImpl();
        User register = accountService.register(user);
        //设置回应格式,返回Json数据
        resp.setContentType("application/json");
        //设置编码格式
        resp.setCharacterEncoding("UTF-8");
        //使用Gson库将对象转换为json字符串
        Gson gson = new Gson();
        //构建响应数据
        //将登录成功的用户的对象转成json数据返回给前端
        String data = gson.toJson(register);
        //数据返回前端
        resp.getWriter().write(data);

    }
}
