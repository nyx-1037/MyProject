package controller.account;


import bean.User;
import service.AccountService;
import service.impl.AccountServiceImpl;
import com.google.gson.Gson;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/login")
public class LoginController extends HttpServlet {


    /**
     * 负责人:
     * 功能:
     * 传入参数acccunt和password 判断用户是否存在
     * 如果账号密码正确 进入对应的首页(员工进入员工首页  管理员进入管理员首页)
     * 如果账号密码错误 回到登录界面 并且额外写一个提示"账号或密码错误"  (具体格式和负责界面的同学沟通)
     * 请求参数:
     * account: string 账号
     * password: string 密码
     * 响应:
     * 如果账号密码正确 进入对应的首页(员工进入员工首页  管理员进入管理员首页)
     * 如果账号密码错误 回到登录界面 并且额外写一个提示"账号或密码错误"  (具体格式和负责界面的同学沟通)
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        resp.getWriter().println("hello");
        System.out.println(123123);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        AccountService accountService = new AccountServiceImpl();
        String account = req.getParameter("account");
        String password = req.getParameter("password");

        //登录成功返回登录成功用户的对象，如果登录失败则返回null
        User user = accountService.login(account, password);

        //设置回应格式,返回Json数据
        resp.setContentType("application/json");
        //设置编码格式
        resp.setCharacterEncoding("UTF-8");
        //使用Gson库将对象转换为json字符串
        Gson gson = new Gson();
        //构建响应数据
        //将登录成功的用户的对象转成json数据返回给前端
        String data = gson.toJson(user);
        //数据返回前端
        resp.getWriter().write(data);
    }
}
