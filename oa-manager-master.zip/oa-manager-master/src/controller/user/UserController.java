package controller.user;

import bean.User;
import common.ResponseResult;
import common.ResponseResultCode;
import service.UserService;
import service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 用户相关操作
 */
@WebServlet("/user")
public class UserController extends HttpServlet {

    private final UserService userService = new UserServiceImpl();

    /**
     * 查询用户信息
     *
     * @param req  请求信息
     * @param resp 响应信息
     * @throws ServletException Servlet异常
     * @throws IOException      IO异常
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        User user = userService.selectUserById(id);
        if (user != null) {
            ResponseResult result = ResponseResult.builder()
                    .code(ResponseResultCode.USER_SELECT_BY_ID_SUCCESS.CODE)
                    .message(ResponseResultCode.USER_SELECT_BY_ID_SUCCESS.MESSAGE)
                    .object(user)
                    .build();
            resp.getWriter().write(result.toJsonString());
        } else {
            ResponseResult result = ResponseResult.builder()
                    .code(ResponseResultCode.USER_SELECT_BY_ID_ERROR.CODE)
                    .message(ResponseResultCode.USER_SELECT_BY_ID_ERROR.MESSAGE)
                    .build();
            resp.getWriter().write(result.toJsonString());
            throw new RuntimeException("该ID：" + id + "无效,没有查询到任何用户");
        }
    }

    /**
     * 添加用户
     *
     * @param req  请求信息 参数传递(name account password email level)
     * @param resp 响应信息
     * @throws ServletException Servlet异常
     * @throws IOException      IO异常
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = new User();
        Boolean InsertResult = userService.insertUser(user);
        if (InsertResult) {
            ResponseResult result = ResponseResult.builder()
                    .code(ResponseResultCode.USER_INSERT_SUCCESS.CODE)
                    .message(ResponseResultCode.USER_INSERT_SUCCESS.MESSAGE)
                    .object(user).build();
            resp.getWriter().write(result.toJsonString());
        } else {
            ResponseResult result = ResponseResult.builder()
                    .code(ResponseResultCode.USER_INSERT_ERROR.CODE)
                    .message(ResponseResultCode.USER_INSERT_ERROR.MESSAGE).build();
            resp.getWriter().write(result.toJsonString());
            // 返回数据后进行报错处理，为了方便做后期全局异常统一处理
            throw new RuntimeException("用户添加失败");
        }
    }

    /**
     * 更新用户信息
     *
     * @param req  请求信息
     * @param resp 响应信息
     * @throws ServletException Servlet异常
     * @throws IOException      IO异常
     */
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = new User();
        user.setId(Integer.parseInt(req.getParameter("id")));
        user.setName(req.getParameter("name"));
        user.setAccount(req.getParameter("account"));
        user.setPassword(req.getParameter("password"));
        user.setEmail(req.getParameter("email"));
        user.setLevel(Integer.parseInt(req.getParameter("level")));
        userService.updateUserById(user);
        // 如果service层不报错证明用户添加陈工
        ResponseResult result = ResponseResult.builder()
                .code(ResponseResultCode.USER_UPDATE_SUCCESS.CODE)
                .message(ResponseResultCode.USER_UPDATE_SUCCESS.MESSAGE)
                .object(user)
                .build();
        resp.getWriter().write(result.toJsonString());
    }

}
