package common;

/**
 * 统一返回信息
 */
public class ResponseResult {
    // 状态码，具体状态参考ResponseCode进行查看
    private Integer code;
    // 描述信息
    private String message;
    // 返回的数据
    private Object object;

    // Builder构建start
    public static ResponseResult.Builder builder() {
        return new ResponseResult.Builder();
    }

    public static class Builder {
        private Integer code;
        private String message;
        private Object object;

        public Builder code(Integer code) {
            this.code = code;
            return this;
        }

        public Builder message(String message) {
            this.message = message;
            return this;
        }

        public Builder object(Object object) {
            this.object = object;
            return this;
        }

        public ResponseResult build() {
            return new ResponseResult(this);
        }
    }
    // Builder构建end

    public ResponseResult() {
    }

    public ResponseResult(Integer code, String message, Object object) {
        this.code = code;
        this.message = message;
        this.object = object;
    }

    private ResponseResult(Builder builder) {
        this.code = builder.code;
        this.message = builder.message;
        this.object = builder.object;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    @Override
    public String toString() {
        return "ResponseResult{" +
                "code='" + code + '\'' +
                ", message='" + message + '\'' +
                ", object=" + object +
                '}';
    }

    /**
     * 将返回数据转成JsonString格式
     *
     * @return Json格式数据
     */
    public String toJsonString() {
        return "{\"code\":\"" + code + "\",\"message\":\"" + message + "\",\"object\":" + object + "}";
    }
}
