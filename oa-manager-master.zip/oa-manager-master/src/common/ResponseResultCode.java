package common;

public enum ResponseResultCode {
    // 成功相关
    USER_INSERT_SUCCESS(200,"添加用户成功"),
    ACCOUNT_LOGIN_SUCCESS(200 , "登录成功"),
    USER_UPDATE_SUCCESS(200,"用户信息更新成功"),
    USER_SELECT_BY_ID_SUCCESS(200 , "成功查询到用户信息"),
    // 失败相关
    USER_INSERT_ERROR(601, "添加用户失败" ),
    USER_SELECT_BY_ID_ERROR(602 , "该ID下没有查询到相关用户"),
    USER_UPDATE_ERROR(603,"用户信息更新失败"),
    ACCOUNT_LOGIN_ERROR(700 , "账户不存在或密码错误,请重新输入后重试！");

    public Integer CODE;
    public String MESSAGE;

    ResponseResultCode(Integer code, String message) {
        this.CODE = code;
        this.MESSAGE = message;
    }
}
