package bean;

import java.util.Date;

public class Check {
    private int id;
    //用户账号
    private String account;
    //用户昵称
    private String name;
    //打卡时间
    private Date checkTime;


    @Override
    public String toString() {
        return "Check{" +
                "id=" + id +
                ", account='" + account + '\'' +
                ", name='" + name + '\'' +
                ", checkTime=" + checkTime +
                '}';
    }

    public Check() {
    }

    public Check(int id, String account, String name, Date checkTime) {
        this.id = id;
        this.account = account;
        this.name = name;
        this.checkTime = checkTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Date checkTime) {
        this.checkTime = checkTime;
    }
}
