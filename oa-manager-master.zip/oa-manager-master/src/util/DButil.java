package util;

import java.sql.*;

public class DButil {
	public static Connection con;
	public static PreparedStatement pstmt;
	public static ResultSet res;

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnection() throws Exception {
		String url = "jdbc:mysql://192.168.16.137:3306/oa_ssm?serverTimezone=GMT";
		String user = "root";
		String password = "123456";
		Connection con1 = DriverManager.getConnection(url, user, password);
		return con1;
	}

	public static PreparedStatement createPreparedStatement(String sql, Object[] objects)
			throws SQLException, Exception {
		PreparedStatement pstmt = getConnection().prepareStatement(sql);
		if (objects != null)
			for (int i = 0; i < objects.length; i++)
				pstmt.setObject(i + 1, objects[i]);
		return pstmt;
	}

	/**
	 * 
	 * @param sql
	 * @param objects
	 * @return
	 */
	public static boolean myexecuteUpdate(String sql, Object[] objects) {
		boolean flag = false;
		try {
			pstmt = createPreparedStatement(sql, objects);
			if (pstmt.executeUpdate() > 0) {
				flag = true;
			} else
				flag = false;
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		} finally {
			close(con, pstmt, null);
		}
		return flag;
	}

	public static ResultSet myexecuteQuery(String sql, Object[] objects) throws Exception {
//		pstmt = createPreparedStatement(sql, objects);
//		res = pstmt.executeQuery();
//		return res;  不能将DBuitl里面的Resultset res关闭
		pstmt = createPreparedStatement(sql, objects);

		return pstmt.executeQuery();
	}

	public static void close(Connection con, Statement stmt, ResultSet res) {
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
		}
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
		}
		if (res != null) {
			try {
				res.close();
			} catch (SQLException e) {
				// TODO 自动生成的 catch 块
				e.printStackTrace();
			}
		}
	}
}
