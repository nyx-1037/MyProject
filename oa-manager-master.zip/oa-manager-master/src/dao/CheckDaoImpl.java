package dao;

import bean.Check;
import util.DButil;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CheckDaoImpl implements CheckDao{
    @Override
    public List<Check> adminSelectCheckByDate(Date startDate, Date endDate) {

        //先转换时间
        Timestamp start = new Timestamp(startDate.getTime());
        Timestamp end = new Timestamp(endDate.getTime());

        // 编写sql语句
        String sql = "select * from checkins where checkTime between ? and ?";
        Object[] o = {start, end};

        //结果集
        ResultSet rs = null;
        List<Check> checks = new ArrayList<>();
        try {
            rs = DButil.myexecuteQuery(sql, o);
            while (rs.next()) {
                Check check = new Check();
                check.setId(rs.getInt("id"));
                check.setCheckTime(rs.getTimestamp("checkTime"));
                check.setAccount(rs.getString("account"));
                check.setName(rs.getString("name"));
                checks.add(check);
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally {
            DButil.close(DButil.con,DButil.pstmt,rs);
        }

        return checks;
    }

    @Override
    public List<Check> selectCheckByDate(String account, Date startDate, Date endDate) {
        Timestamp start = new Timestamp(startDate.getTime());
        Timestamp end = new Timestamp(endDate.getTime());
        String sql = "select * from checkins where account = ? and checkTime between ? and ?";
        Object[] o = {account, start, end};
        //结果集

        ResultSet rs = null;
        List<Check> checks = new ArrayList<>();
        try {
            rs = DButil.myexecuteQuery(sql, o);
            while (rs.next()) {
                Check check = new Check();
                check.setId(rs.getInt("id"));
                check.setCheckTime(rs.getTimestamp("checkTime"));
                check.setAccount(rs.getString("account"));
                check.setName(rs.getString("name"));
                checks.add(check);
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally {
            DButil.close(DButil.con,DButil.pstmt,rs);
        }

        return checks;
    }

    @Override
    public Check insertCheck(Check check) {
        String sql = "insert into checkins(id, account, name, checkTime) values(null, ? ,? ,?)";
        Object[] o = {check.getAccount(), check.getName(), new Timestamp(check.getCheckTime().getTime())};

        boolean b = DButil.myexecuteUpdate(sql, o);
        if (b){
            check.setId(selectCheckByAccount(check.getAccount()));
            return check;
        }
        return null;
    }

    @Override
    public Check selectToDayCheckByAccount(String account) {
        String sql = "select * from checkins where account = ? and date(checkTime) = CURDATE()";
        Object[] o = {account};
        ResultSet rs = null;
        Check check = null;

        try {
            rs = DButil.myexecuteQuery(sql,o);
            if (rs.next()){
                check = new Check();
                check.setId(rs.getInt("id"));
                check.setCheckTime(rs.getTimestamp("checkTime"));
                check.setAccount(rs.getString("account"));
                check.setName(rs.getString("name"));
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally {
            DButil.close(DButil.con,DButil.pstmt,rs);
        }

        return check;
    }

    @Override
    public List<String> selectAllAccount() {
        String sql = "select account from user";
        Object[] o = {};
        ResultSet rs = null;
        List<String> accounts = new ArrayList<>();

        try {
            rs = DButil.myexecuteQuery(sql,o);
            while (rs.next()){
                accounts.add(rs.getString("account"));
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally {
            DButil.close(DButil.con,DButil.pstmt,rs);
        }

        return accounts;
    }

    public int selectCheckByAccount(String account) {
        String sql = "select id from checkins where account = ?";
        Object[] o = {account};
        ResultSet rs = null;
        int id = -1;
        try {
            rs = DButil.myexecuteQuery(sql,o);
            if (rs.next()){
                id = rs.getInt("id");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally {
            DButil.close(DButil.con,DButil.pstmt,rs);
        }
        return id;
    }

}
