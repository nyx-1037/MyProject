package dao;


import DBtool.DBtool;
import bean.User;

import java.sql.*;

import static DBtool.DBtool.*;

public class UserDaoImpl implements UserDao {
    //向数据库插入用户数据(注意 参数的id为空 返回的user要带上id

    /**
     * 负责人:
     * 功能: 向数据库添加一条用户信息
     * 参数:
     * user: 用户信息   id为空
     * 返回值:
     * 新增的用户数据(如果添加失败 返回null)
     */
    @Override
    public User insertUser(User user) {
        int flag = 0;
        String sql = "insert into User(name, account, password, email, level) values (?,?,?,?,?)";
        try {
            flag = DBtool.executeUpdate(sql, user.getName(), user.getAccount(), user.getPassword(), user.getEmail(), user.getLevel());
            //检查是否插入成功,失败返回null
            if (flag == 0) {
                return null;
            }
            //自动添加序号
            user = DBtool.setUserGeneratedId(sql, user);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            DBtool.close();//关闭释放资源
        }
        return user;
    }


    //修改user信息(注意 根据用户id来修改  返回更新后的user数据)

    /**
     * 负责人:
     * 功能: 修改数据库中指定的用户信息
     * 参数:
     * user: 用户信息   id是用户id  其它值是修改后的值
     * 返回值:
     * 更新后的user数据(如果更新失败 返回null)
     */
    @Override
    public User updateUserById(User user) {
        int flag = 0;
        String sql = "update User set name=?,account=?,password=?,email=?,level=? where id=?";
        try {
            flag = DBtool.executeUpdate(sql, user.getName(), user.getAccount(), user.getPassword(), user.getEmail(), user.getLevel(), user.getId());
            //检查是否插入成功,失败返回null
            if (flag == 0) {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            DBtool.close();//关闭释放资源
        }
        return user;
    }

    @Override
    public User selectUserByAccount(String Account) {
        String query = "SELECT * FROM user WHERE account = ?";
        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            // 设置查询参数
            pstmt.setString(1, Account);

            // 执行查询
            ResultSet rs = pstmt.executeQuery();

            // 检查结果
            if (rs.next()) {
                // 如果用户存在，创建User对象并填充数据
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                // ... 设置其他字段
                return user;
            } else {
                // 用户不存在，返回null
                return null;
            }
        } catch (SQLException e) {
            // 处理异常，例如打印堆栈跟踪或记录日志
            e.printStackTrace();
            return null;
        }
    }


    @Override
    public User selectUserById(int id) {
        String query = "SELECT * FROM user WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            // 设置查询参数
            pstmt.setInt(1, id);

            // 执行查询
            ResultSet rs = pstmt.executeQuery();

            // 检查结果
            if (rs.next()) {
                // 如果用户存在，创建User对象并填充数据
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                // ... 设置其他字段
                return user;
            } else {
                // 用户不存在，返回null
                return null;
            }
        } catch (SQLException e) {
            // 处理异常，例如打印堆栈跟踪或记录日志
            e.printStackTrace();
            return null;
        }
    }
}

