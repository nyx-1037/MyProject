package dao;


import bean.User;

public interface UserDao {

    //向数据库插入用户数据(注意 参数的id为空 返回的user要带上id
    /**
     * 负责人:
     * 功能: 向数据库添加一条用户信息
     * 参数:
     *  user: 用户信息   id为空
     *  返回值:
     *   新增的用户数据(如果添加失败 返回null)
     *
     */
    public User insertUser(User user);

    //修改user信息(注意 根据用户id来修改  返回更新后的user数据)

    /**
     * 负责人:
     * 功能: 修改数据库中指定的用户信息
     * 参数:
     *  user: 用户信息   id是用户id  其它值是修改后的值
     *  返回值:
     *   更新后的user数据(如果更新失败 返回null)
     *
     */
    public User updateUserById(User user);


    /**
     * 负责人:
     * 功能: 根据账号查询用户信息 不存在返回null
     *
     */

    public User selectUserByAccount(String Account) ;
    /**
     * 负责人:
     * 功能: 根据id查询用户信息 不存在返回null
     *
     */
    public User selectUserById(int uid);



}

