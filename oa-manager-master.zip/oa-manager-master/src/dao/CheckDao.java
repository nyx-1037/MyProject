package dao;


import bean.Check;

import java.util.Date;
import java.util.List;

public interface CheckDao {
    /**
     * 根据时间范围 查询所有的打卡信息
     * 参数:
     *  startDate: 时间范围的起始
     *  endDate: 时间范围的结束
     *  返回值:
     *      所有在时间范围内的打卡信息
     *
     */
    public List<Check> adminSelectCheckByDate(Date startDate, Date endDate);
    /**
     * 根据时间范围和用户账号 查询所有的打卡信息
     * 参数:
     *  account: 用户账号
     *  startDate: 时间范围的起始
     *  endDate: 时间范围的结束
     *  返回值:
     *      指定用户的 所有在时间范围内的打卡信息
     *
     */
    public List<Check> selectCheckByDate(String account, Date startDate, Date endDate);

    /**
     * 向数据库添加一条打卡信息
     * 参数:
     *  check: 打卡信息   包括account和name 和checkTime
     *  返回值:
     *   新增的打卡数据(包括id和checkTime, 如果添加失败 返回null)
     *
     */
    public Check insertCheck(Check check);


    /**
     * 负责人:
     * 功能: 根据account 查询今天的打卡情况
     * 参数:
     *  account: 用户的account
     *  返回值:
     *   如果今天已经打卡了 返回打卡数据
     *   如果今天没打卡 返回null
     *
     */
    public Check selectToDayCheckByAccount(String account);

    public List<String> selectAllAccount();

}
