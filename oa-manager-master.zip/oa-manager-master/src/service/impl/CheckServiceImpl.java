package service.impl;

import bean.Check;
import bean.User;
import dao.CheckDao;
import dao.UserDao;
import dao.CheckDaoImpl;
import dao.UserDaoImpl;
import service.CheckService;
import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.TextStyle;
import java.time.temporal.TemporalAdjusters;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CheckServiceImpl implements CheckService {

    CheckDao checkDao = new CheckDaoImpl();
    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
    List<String> accounts = checkDao.selectAllAccount();
    UserDao userDao = new UserDaoImpl();

    /**
     * 负责人:
     * 功能: 打卡
     *      记得先检查今天该用户是否已经打卡
     *  参数:
     *      打卡者的account和name
     *   返回值:
     *      如果打卡成功 返回打卡信息
     *      如果打卡失败(比如重复打卡, 返回null)
     */
    @Override
    public Check checkIn(String account, String name) {
        Check check = null;
        check = checkDao.selectToDayCheckByAccount(account);
        if (check == null) {
            check = new Check();
            check.setAccount(account);
            check.setName(name);
            check.setCheckTime(new Date());
            check = checkDao.insertCheck(check);
            return check;
        }else{
            return null;
        }

    }
    /**
     *   负责人:
     *   功能:
     *       根据参数 查询对应的打卡情况
     *   参数:
     *       id:
     *          表示查询的用户id
     *       val:
     *          如果按周查询 值是1~5 表示当月第几周 (周一在几月就算是那个月的 比如2.28是周一 那么3月1周是3.6~3.11)
     *          如果按月查询 值是1~12 表示今年第几月
     *          如果按年查询 值是2000~2024 表示哪年
     *   返回值:
     *       json串
     *      Week:
     *          {
     *              [date: '周一', time: '08:02', statu: '迟到'}],
     *              [date: '周二', time: '07:52', statu: '正常'}],
     *              [date: '周三', time: '', statu: '请假'}],
     ...]}
     Month:
     {
     [{week: 3, check: 5, data: 7}],[....] }    //本月第几周, 实际打卡次数, 应打卡次数
     Year:
     {
     [{month: 3, check: 28, data: 31, statu: '未全勤'}],[....] }    //第几月, 实际打卡次数, 应打卡次数, 是否全勤
     }
     *
     * */
    @Override
    public String getCheckByWeek(String uid, int week) {

        LocalDate localDate = LocalDate.now();
        LocalDate localDate1st = LocalDate.of(localDate.getYear(), localDate.getMonth(), 1);
        LocalDate mondayFirst = localDate1st.with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY));
        LocalDate LastDayOfMonth = YearMonth.now().atEndOfMonth();


        LocalDate begin = mondayFirst.plusWeeks(week - 1);
        LocalDate end = mondayFirst.plusWeeks(week).minusDays(1);

        if (begin.isBefore(LastDayOfMonth) || begin.isEqual(LastDayOfMonth)) {
            List<Check> checks = checkDao.selectCheckByDate(uid, convertToDate(begin), convertToDate(end));

            JSONArray jsonArray = new JSONArray();
            //String dayOfWeekStr = currentDate.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.getDefault());
            for (Check check : checks) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("date", convertToLocalDate(check.getCheckTime()).getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.getDefault()));
                jsonObject.put("time", sdf.format(check.getCheckTime()));
                jsonArray.put(jsonObject);
            }
            return jsonArray.toString();
        }
        return "";
    }

    @Override
    public String getCheckByMonth(String uid, int month) {

        LocalDate localDate = LocalDate.now();
        LocalDate localDate1st = LocalDate.of(localDate.getYear(), month, 1);
        LocalDate mondayFirst = localDate1st.with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY));
        LocalDate LastDayOfMonth = YearMonth.of(localDate.getYear(),month).atEndOfMonth();
        LocalDate monday = mondayFirst;

        int i = 1;
        JSONArray jsonArray = new JSONArray();
        while((monday.isBefore(localDate) || monday.isEqual(localDate)) && (monday.isBefore(LastDayOfMonth) || monday.isEqual(LastDayOfMonth))) {

            List<Check> checks = checkDao.selectCheckByDate(uid, convertToDate(monday), convertToDate(monday.plusDays(6)));

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("week",i++);
            jsonObject.put("check",checks.size());
            jsonObject.put("date",7);
            jsonArray.put(jsonObject);

            monday = monday.plusWeeks(1);
        }

        return jsonArray.toString();
    }

    @Override
    public String getCheckByYear(String uid, int year) {
        LocalDate localDate = LocalDate.now();
        int nowYear = localDate.getYear();
        int month = localDate.getMonthValue();

        YearMonth yearMonth = YearMonth.of(year, 1);
        YearMonth nowYearMonth = YearMonth.of(nowYear, 1);

        JSONArray jsonArray = new JSONArray();

        if (nowYear > year) {
            for (int i = 1; i <= 12; i++){
                LocalDate endOfMonth = yearMonth.atEndOfMonth();
                LocalDate firstDayOfMonth = yearMonth.atDay(1);
                List<Check> checks = checkDao.selectCheckByDate(uid, convertToDate(firstDayOfMonth), convertToDate(endOfMonth));
                JSONObject jsonObject = new JSONObject();

                jsonObject.put("month",i);
                jsonObject.put("check",checks.size());
                jsonObject.put("data",endOfMonth.getDayOfMonth());

                if (checks.size() < endOfMonth.getDayOfMonth()){
                    jsonObject.put("status","未全勤");
                }else{
                    jsonObject.put("status","全勤");
                }

                jsonArray.put(jsonObject);

                yearMonth = yearMonth.plusMonths(1);
            }
        }else if (nowYear == year) {
            for (int i = 1; i < month; i++){

                LocalDate endOfMonth = nowYearMonth.atEndOfMonth();
                LocalDate firstDayOfMonth = nowYearMonth.atDay(1);
                List<Check> checks = checkDao.selectCheckByDate(uid, convertToDate(firstDayOfMonth), convertToDate(endOfMonth));
                JSONObject jsonObject = new JSONObject();

                jsonObject.put("month",i);
                jsonObject.put("check",checks.size());
                jsonObject.put("data",endOfMonth.getDayOfMonth());

                if (checks.size() < endOfMonth.getDayOfMonth()){
                    jsonObject.put("status","未全勤");
                }else{
                    jsonObject.put("status","全勤");
                }

                jsonArray.put(jsonObject);

                nowYearMonth = nowYearMonth.plusMonths(1);
            }


            LocalDate firstDayOfMonth = nowYearMonth.atDay(1);
            List<Check> checks = checkDao.selectCheckByDate(uid, convertToDate(firstDayOfMonth), convertToDate(localDate));
            JSONObject jsonObject = new JSONObject();

            jsonObject.put("month",month);
            jsonObject.put("check",checks.size());
            jsonObject.put("data",localDate.getDayOfMonth());

            if (checks.size() < localDate.getDayOfMonth()){
                jsonObject.put("status","未全勤");
            }else{
                jsonObject.put("status","全勤");
            }

            jsonArray.put(jsonObject);
        }
        return jsonArray.toString();
    }

    @Override
    public String adminGetCheckByWeek(int week) {

        LocalDate localDate = LocalDate.now();
        LocalDate localDate1st = LocalDate.of(localDate.getYear(), localDate.getMonth(), 1);
        LocalDate mondayFirst = localDate1st.with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY));
        LocalDate LastDayOfMonth = YearMonth.now().atEndOfMonth();

        LocalDate begin = mondayFirst.plusWeeks(week - 1);
        LocalDate end = mondayFirst.plusWeeks(week).minusDays(1);

        JSONArray jsonArray0 = new JSONArray();

        for (String account : accounts) {

            User user = userDao.selectUserByAccount(account);

            JSONObject object = new JSONObject();

            object.put("name",user.getName());

            JSONArray jsonArray = new JSONArray();

            if (begin.isBefore(LastDayOfMonth) || begin.isEqual(LastDayOfMonth)) {

                List<Check> checks = checkDao.selectCheckByDate(account, convertToDate(begin), convertToDate(end));

                //String dayOfWeekStr = currentDate.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.getDefault());
                for (Check check : checks) {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("date", convertToLocalDate(check.getCheckTime()).getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.getDefault()));
                    jsonObject.put("time", sdf.format(check.getCheckTime()));
                    jsonArray.put(jsonObject);
                }

            }
            object.put("data", jsonArray);

            jsonArray0.put(object);

        }
        return jsonArray0.toString();
    }

    @Override
    public String adminGetCheckByMonth(int month) {

        LocalDate localDate = LocalDate.now();
        LocalDate localDate1st = LocalDate.of(localDate.getYear(), month, 1);
        LocalDate mondayFirst = localDate1st.with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY));
        LocalDate LastDayOfMonth = YearMonth.of(localDate.getYear(),month).atEndOfMonth();


        JSONArray jsonArray0 = new JSONArray();

        for (String account : accounts) {

            User user = userDao.selectUserByAccount(account);
            JSONObject object = new JSONObject();

            object.put("name",user.getName());

            int i = 1;
            LocalDate monday = mondayFirst;

            JSONArray jsonArray = new JSONArray();
            while((monday.isBefore(localDate) || monday.isEqual(localDate)) && (monday.isBefore(LastDayOfMonth) || monday.isEqual(LastDayOfMonth))) {

                List<Check> checks = checkDao.selectCheckByDate(account, convertToDate(monday), convertToDate(monday.plusDays(6)));

                JSONObject jsonObject = new JSONObject();
                jsonObject.put("week",i++);
                jsonObject.put("check",checks.size());
                jsonObject.put("date",7);
                jsonArray.put(jsonObject);

                monday = monday.plusWeeks(1);
            }

            object.put("data", jsonArray);
            jsonArray0.put(object);
        }

        return jsonArray0.toString();
    }

    @Override
    public String adminGetCheckByYear(int year) {
        LocalDate localDate = LocalDate.now();
        int nowYear = localDate.getYear();
        int month = localDate.getMonthValue();

        JSONArray jsonArray0 = new JSONArray();

        for (String account : accounts) {

            User user = userDao.selectUserByAccount(account);

            JSONObject object = new JSONObject();
            object.put("name",user.getName());

            YearMonth yearMonth = YearMonth.of(year, 1);
            YearMonth nowYearMonth = YearMonth.of(nowYear, 1);

            JSONArray jsonArray = new JSONArray();

            if (nowYear > year) {
                for (int i = 1; i <= 12; i++) {
                    LocalDate endOfMonth = yearMonth.atEndOfMonth();
                    LocalDate firstDayOfMonth = yearMonth.atDay(1);
                    List<Check> checks = checkDao.selectCheckByDate(account, convertToDate(firstDayOfMonth), convertToDate(endOfMonth));
                    JSONObject jsonObject = new JSONObject();

                    jsonObject.put("month", i);
                    jsonObject.put("check", checks.size());
                    jsonObject.put("data", endOfMonth.getDayOfMonth());

                    if (checks.size() < endOfMonth.getDayOfMonth()) {
                        jsonObject.put("status", "未全勤");
                    } else {
                        jsonObject.put("status", "全勤");
                    }

                    jsonArray.put(jsonObject);

                    yearMonth = yearMonth.plusMonths(1);
                }
            } else if (nowYear == year) {
                for (int i = 1; i < month; i++) {

                    LocalDate endOfMonth = nowYearMonth.atEndOfMonth();
                    LocalDate firstDayOfMonth = nowYearMonth.atDay(1);
                    List<Check> checks = checkDao.selectCheckByDate(account, convertToDate(firstDayOfMonth), convertToDate(endOfMonth));
                    JSONObject jsonObject = new JSONObject();

                    jsonObject.put("month", i);
                    jsonObject.put("check", checks.size());
                    jsonObject.put("data", endOfMonth.getDayOfMonth());

                    if (checks.size() < endOfMonth.getDayOfMonth()) {
                        jsonObject.put("status", "未全勤");
                    } else {
                        jsonObject.put("status", "全勤");
                    }

                    jsonArray.put(jsonObject);

                    nowYearMonth = nowYearMonth.plusMonths(1);
                }


                LocalDate firstDayOfMonth = nowYearMonth.atDay(1);
                List<Check> checks = checkDao.selectCheckByDate(account, convertToDate(firstDayOfMonth), convertToDate(localDate));
                JSONObject jsonObject = new JSONObject();

                jsonObject.put("month", month);
                jsonObject.put("check", checks.size());
                jsonObject.put("data", localDate.getDayOfMonth());

                if (checks.size() < localDate.getDayOfMonth()) {
                    jsonObject.put("status", "未全勤");
                } else {
                    jsonObject.put("status", "全勤");
                }

                jsonArray.put(jsonObject);
            }

            object.put("data", jsonArray);

            jsonArray0.put(object);
        }
        return jsonArray0.toString();
    }

    public Date convertToDate(LocalDate localDate) {
        // 将LocalDate转换为LocalDateTime的午夜时刻
        LocalDateTime localDateTime = localDate.atStartOfDay();
        // 将LocalDateTime转换为Instant
        Instant instant = localDateTime.atZone(ZoneId.systemDefault()).toInstant();
        // 将Instant转换为Date
        return Date.from(instant);
    }


    public LocalDate convertToLocalDate(Date date) {
        // 将Date转换为Instant
        Instant instant = date.toInstant();
        // 使用系统默认时区将Instant转换为LocalDate
        return instant.atZone(ZoneId.systemDefault()).toLocalDate();
    }

}
