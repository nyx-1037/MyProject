package service.impl;

import bean.User;
import common.ResponseResultCode;
import dao.UserDao;
import dao.UserDaoImpl;
import service.UserService;

public class UserServiceImpl implements UserService {

    private final UserDao userDao = new UserDaoImpl();

    @Override
    public User selectUserById(int id) {
        return userDao.selectUserById(id);
    }

    @Override
    public Boolean insertUser(User user) {
        User selectUser = userDao.selectUserByAccount(user.getAccount());
        if (selectUser != null) {
            return false;
        } else {
            userDao.insertUser(user);
            return true;
        }
    }

    @Override
    public void updateUserById(User user) {
        User selectUser = userDao.selectUserById(user.getId());
        if (selectUser != null) {

            //return false;
            throw new RuntimeException(ResponseResultCode.USER_SELECT_BY_ID_ERROR.MESSAGE);
        } else {
            userDao.updateUserById(user);
        }
    }
}
