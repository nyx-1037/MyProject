package service.impl;

import bean.User;
import dao.UserDaoImpl;
import service.AccountService;


public class AccountServiceImpl implements AccountService {

    /**
     * 负责人：TMXK
     * 功能：用户登录
     * @param account
     * @param password
     * @return 成功则返回User,失败返回null
     */
    @Override
    public User login(String account, String password) {

        //获得dao对象
        UserDaoImpl dao = new UserDaoImpl();
        //查询对应的账号
        User user = dao.selectUserByAccount(account);
        if (user == null) {
            return null;
        }
        if (user.getPassword().equals(password)) {//账号密码均正确，则返回对应的用户类
            return user;
        }
        else return null;
    }

    /**
     * 负责人：TMXK
     * 功能：注册新用户
     * @param user
     * @return 注册成功则返回新增加用户，否则返回null
     */
    @Override
    public User register(User user) {
        //获得用户持久化对象
        UserDaoImpl dao = new UserDaoImpl();
        //插入新的用户，成功则获得新用户的信息，否则返回null
        User user1 = dao.insertUser(user);
        return user1;
    }

    /**
     * 负责人：TMXK
     * 功能：忘记密码
     * @param account
     * @param password
     * @param email
     * @return 如果邮箱与数据库中的邮箱一致，则将新的密码更新
     */
    @Override
    public User forgetPass(String account, String password, String email) {
        UserDaoImpl dao = new UserDaoImpl();
        User user = dao.selectUserByAccount(account);
        //用户查询失败，返回null
        if (user == null) {
            return null;
        }
        //邮箱账号一致，则更新密码
        if(user.getEmail().equals(email)) user.setPassword(password);
        //更新数据库
        User user1 = dao.updateUserById(user);
        //返回更新后的user
        return user1;
    }


}
