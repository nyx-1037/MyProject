package service;

import bean.User;

public interface UserService {

    /**
     * 根据Id查询用户信息
     * @param id 用户id
     * @return 用户信息
     */
    User selectUserById(int id);

    Boolean insertUser(User user);

    void updateUserById(User user);
}
