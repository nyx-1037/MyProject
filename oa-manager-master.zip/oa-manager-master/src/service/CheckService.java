package service;


import bean.Check;

public interface CheckService {


    /**
     * 负责人:
     * 功能: 打卡
     *      记得先检查今天该用户是否已经打卡
     *  参数:
     *      打卡者的account和name
     *   返回值:
     *      如果打卡成功 返回打卡信息
     *      如果打卡失败(比如重复打卡, 返回null)
     */
    public Check checkIn(String account, String name);

     /**
     *   负责人:
     *   功能:
     *       根据参数 查询对应的打卡情况
     *   参数:
     *       id:
     *          表示查询的用户id
     *       val:
     *          如果按周查询 值是1~5 表示当月第几周 (周一在几月就算是那个月的 比如2.28是周一 那么3月1周是3.6~3.11)
     *          如果按月查询 值是1~12 表示今年第几月
     *          如果按年查询 值是2000~2024 表示哪年
     *   返回值:
     *       json串
     *      Week:
     *          {
     *              [date: '周一', time: '08:02', statu: '迟到'}],
     *              [date: '周二', time: '07:52', statu: '正常'}],
     *              [date: '周三', time: '', statu: '请假'}],
                    ...]}
            Month:
                 {
                 [{week: 3, check: 5, data: 7}],[....] }    //本月第几周, 实际打卡次数, 应打卡次数
            Year:
                 {
                 [{month: 3, check: 28, data: 31, statu: '未全勤'}],[....] }    //第几月, 实际打卡次数, 应打卡次数, 是否全勤
                 }
     *
     * */
    public String getCheckByWeek(String uid,int week);
    public String getCheckByMonth(String uid,int month);
    public String getCheckByYear(String uid,int year);



    /**
     *   负责人:
     *   功能:
     *       展示所有人对应的打卡情况
     *   参数:
     *       val:
     *          如果按周查询 值是1~5 表示当月第几周 (周一在几月就算是那个月的 比如2.28是周一 那么3月1周是3.6~3.11)
     *          如果按月查询 值是1~12 表示今年第几月
     *          如果按年查询 值是2000~2024 表示哪年
     *   返回值:
     *       json串    在showCheck的基础上套了一层[{name:xx, date:{}}, {name:xx, date:{}}]
     Week:
     {[
         {
             name: '张三', data:{
                 [{date: '周一', time: '08:02', statu: '迟到'},
                 {date: '周二', time: '07:52', statu: '正常'},
                 {date: '周三', time: '', statu: '请假'}],
                 ...]
             }
         },{
             name: '李四', data:{
                 [{date: '周一', time: '08:02', statu: '迟到'},
                 {date: '周二', time: '07:52', statu: '正常'},
                 {date: '周三', time: '', statu: '请假'}],
                 ...]
             }
         }
     ]}
     Month:
     {[
         {
             name: '张三', data:{
                 [{week: 3, check: 5, data: 7},{....}] //本月第几周, 实际打卡次数, 应打卡次数
             }
         },{
             name: '李四', data:{
                [{week: 3, check: 5, data: 7},{....}] //本月第几周, 实际打卡次数, 应打卡次数
             }
         }
     ]}
     Year:
     {[
         {
             name: '张三', data:{
                [{month: 3, check: 28, data: 31, statu: '未全勤'},{....}]    //第几月, 实际打卡次数, 应打卡次数, 是否全勤
             }
         },{
             name: '李四', data:{
                [{month: 3, check: 28, data: 31, statu: '未全勤'},{....}]    //第几月, 实际打卡次数, 应打卡次数, 是否全勤
            }

         }
     ]}
     *
     * */
    public String adminGetCheckByWeek(int week);
    public String adminGetCheckByMonth(int month);
    public String adminGetCheckByYear(int year);
}
