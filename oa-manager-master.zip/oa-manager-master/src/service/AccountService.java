package service;


import bean.Check;
import bean.User;

import java.util.List;

public interface AccountService {
    /**
    * 负责人:
    * 功能:
    *   登录验证
    *   如果账号密码匹配 返回用户信息
    *   如果账号密码不匹配 返回null
    * 参数:
    *   account: 用户账号
    *   password: 用户密码
    * 返回值:
    *   如果账号密码匹配 返回用户信息
    *   如果账号密码不匹配 返回null
    *
    * */
    public User login(String account, String password);

    /**
     * 负责人:
     * 功能:
     *   注册账号
     *   如果账号不存在 向数据库中插入新用户数据(权限默认为1) 返回新的用户数据(包括权限和id)
     *   如果账号存在 返回null
     * 参数:
     *   除了id和权限以外 其它属性都有值
     * 返回值:
     *   如果账号密码匹配 返回用户信息
     *   如果账号密码不匹配 返回null
     *
     * */
    public User register(User user);

    /**
     * 负责人:
     * 功能:
     *   忘记密码
     *   如果账号和邮箱对应 修改数据库中用户的password属性 返回新的user信息
     *   如果不对应 返回null
     * 参数:
     *   account: 用户账号
     *   password: 用户新密码
     *   email: 用户邮箱
     * 返回值:
     *   如果账号和邮箱对应 返回新的user信息
     *   如果账号和邮箱对应 返回null
     *
     * */
    public User forgetPass(String account, String password, String email);

}
