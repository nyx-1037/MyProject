package DBtool;


import bean.User;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBtool {
    //存储数据库连接的相关信息
    public static String driver = "com.mysql.cj.jdbc.Driver";
    public static String url="jdbc:mysql://192.168.16.137:3306/oa_ssm?serverTimezone=UTC&amp&useSSL=false&autoReconnect=true";
    public static String username="root";
    public static String password="123456";
    public static Connection conn = null;
    public static PreparedStatement ps = null;
    public static ResultSet rs = null;
    //数据库连接的初始操作
    static {
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url,username,password);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //获取数据库连接对象
    public static Connection getConnection() { return conn;}

    //执行更新操作(插入、更新)操作
    public static int executeUpdate(String sql, Object...param){
        int flag=0;
        try {
            ps = conn.prepareStatement(sql);
            for (int i = 0; i < param.length; i++) {
                ps.setObject(i+1,param[i]);
            }
            flag=ps.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }
        return flag;
    }

    //自动添加编号
    public static User setUserGeneratedId(String sql, User user){
        try {
            ps = conn.prepareStatement(sql);
            rs = ps.getGeneratedKeys();
            if (rs.next()){
                user.setId(rs.getInt(1));
            }
            else {
                return null;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return user;
    }

    //关闭数据库连接以及释放资源
    public static void close(){
        try {
            if (conn != null){
                conn.close(); //关闭数据库连接
            }
            if (rs != null){
                rs.close(); //关闭结果集
            }
            if (ps != null){
                ps.close(); //关闭预编译语句对象
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
