<template>
    <div ref="chart" :style="{ width: '600px', height: '400px', }"></div>
  </template>
  
  <script setup>
  import { ref, onMounted, reactive } from 'vue';
  import * as echarts from 'echarts';
  
  // 定义图表配置
  const option = reactive({
    title: {
      text: '打卡次数统计',
      textStyle: {
      color: 'white',  
    }
    },
    xAxis: {
      type: 'category',
      data: ['jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul']
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        data: [30, 25, 24, 28, 23, 27, 26],
        type: 'line'
      }
    ]
  });
  
  // 定义 ref 来获取 DOM 节点
  const chart = ref(null);
  
  // 在组件挂载后初始化图表
  onMounted(() => {
    const myChart = echarts.init(chart.value);
    window.addEventListener('resize', function() {
    myChart.resize();
  },);
    myChart.setOption(option);
  });
  </script>
  
  <style scoped>
    
  </style>
  