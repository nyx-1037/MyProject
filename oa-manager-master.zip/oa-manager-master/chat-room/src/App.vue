<template>
  <RouterView />
</template>

<script lang="ts" setup>
import { RouterView } from 'vue-router'
</script>

<style scoped>
</style>
