import { createRouter, createWebHistory } from 'vue-router'
import Homepage from '../views/index.vue'
import login from '@/components/loginView.vue'
import LoginAndRegister from "@/components/LoginAndRegister.vue";
import Forget from "@/components/Forget.vue";
import PhoneVerify from "@/components/PhoneVerify.vue";
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [ 
    {
      path: '/',
      component: login,
      children: [
        {
          path: '',
          name: 'login',
          component: LoginAndRegister,
          meta: { title: 'Login' },
        },
        {
          path:'forget',//不要加斜杠
          component: Forget,
      },
      {
          path:'phone',//不要加斜杠
          component: PhoneVerify,
      },
      ]
    },
    {
      path: '/homepage',
      name: 'homepage',
      component : Homepage,
      children: [
        {
          path: '',
          name: 'staff',
          component:()=>import("@/views/staffHomepage.vue"),
          meta: { title: 'Staff' },      
      },
      {
        path: 'manage',
        name: 'manage',
        component:()=>import("@/views/manageHome.vue"),
        meta: { title: 'Manage' },
      },
      {
        path: 'apply',
        name: 'apply',
        component:()=>import("@/views/apply.vue"),
        meta: { title: 'Apply' },
      },
    ]
    }
  ]
})

export default router
