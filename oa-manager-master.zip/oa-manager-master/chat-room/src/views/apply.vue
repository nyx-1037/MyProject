<template>
   <div class="container">
    <el-form :model="form" label-width="auto" style="width: 600px"class="custom-form">
      <el-form-item label=" 姓名">
        <el-input v-model="form.name" />
      </el-form-item>
      <el-form-item label="职位">
        <el-select v-model="form.region" placeholder="please select your zone">
          <el-option label="学长" value="shanghai" />
          <el-option label="学员" value="beijing" />
        </el-select>
      </el-form-item>
      <el-form-item label="日期">
        <el-col :span="11">
          <el-date-picker
            v-model="form.date1"
            type="date"
            placeholder="Pick a date"
            style="width: 100%"
          />
        </el-col>
        <el-col :span="2" class="text-center">
          <span class="text-gray-500">-</span>
        </el-col>
        <el-col :span="11">
          <el-time-picker
            v-model="form.date2"
            placeholder="Pick a time"
            style="width: 100%"
          />
        </el-col>
      </el-form-item>
      <el-form-item label="立刻送达">
        <el-switch v-model="form.delivery" />
      </el-form-item>
      <el-form-item label="Activity type">
        <el-checkbox-group v-model="form.type">
          <el-checkbox value="Online activities" name="type">
            Online activities
          </el-checkbox>
          <el-checkbox value="Family activities" name="type">
            Family activities
          </el-checkbox>
          <el-checkbox value="Offline activities" name="type">
            Offline activities
          </el-checkbox>
          <el-checkbox value="Simple Free" name="type">
            Simple Free
          </el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <el-form-item label="申请原因">
        <el-input v-model="form.desc" type="textarea" />
      </el-form-item>
      <el-form-item class="centered-buttons">
        <el-button type="primary" @click="onSubmit">Create</el-button>
        <el-button>Cancel</el-button>
      </el-form-item>
    </el-form>
   </div>
  </template>
  
  <script lang="ts" setup>
  import { reactive } from 'vue'
  
  // do not use same name with ref
  const form = reactive({
    name: '',
    region: '',
    date1: '',
    date2: '',
    delivery: false,
    type: [],
    resource: '',
    desc: '',
  })
  
  const onSubmit = () => {
    alert('submit!')
  }
  </script>
  <style lang="scss" scoped>
  .container {
  display: flex;
  justify-content: center; 
  align-items: center;
  height: 100vh;            
  background-color: #f5f5f5; 
  .custom-form{
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: space-evenly
  }
}
.centered-buttons {
    margin: 0 auto;
}
</style>