<script setup>
import { ref } from 'vue'
import counterchart from '@/components/counter.vue'
import { Delete, Edit, Search, Share, Upload } from '@element-plus/icons-vue'
import { useRouter } from 'vue-router';
const router = useRouter();
function goToNav() {
  router.push({ name: 'apply' });
}
let stopTime = ref('8:00');
const emp_list = ref([
   { id: 1, name: '东东哥', avater: '' },
   { id: 2, name: '东东姐', avater: '' },
   { id: 3, name: '东东妹', avater: '' },
   { id: 4, name: '东东弟', avater: '' },
]);
const currentTime = ref('');
const getClientTime = () => {
  const date = new Date();
  const weeks = ['天', '一', '二', '三', '四', '五', '六'];
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const day = date.getDate().toString().padStart(2, '0');
  const week = weeks[date.getDay()];
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  const seconds = date.getSeconds().toString().padStart(2, '0');
  
  currentTime.value = `当前时间：${year}年${month}月${day}日 星期${week} ${hours}:${minutes}:${seconds}`;
};
const showClientTime = () => {
  getClientTime();
  alert(currentTime.value);
};

</script>
<template>
  <el-row>
    <el-col :span="8"><div class="grid-content ep-bg-purple-dark" />
      <el-button color="#4d5b2f" type="success">点击打卡</el-button>
      <el-button color="#4d5b2f" type="success" @click="showClientTime">Show Client Time</el-button>
      <i>截止打卡时间：{{stopTime}}</i>
    </el-col>   
  </el-row>
  <el-row :gutter="0" class="demo">
    <el-col :span="12"><div class="grid-content ep-bg-purple" />
      <counterchart /></el-col>
    <el-col :span="11"><div class="grid-content ep-bg-purple" />
      <el-scrollbar>
          <div class="emp-box">
              <h3>正在摸鱼的员工</h3>
              <div class="emp">
                <div class="emp-item" v-for="item in emp_list">
                    <el-avatar :size="50":src="item.avater">
                      <el-icon size="20px"><User /></el-icon>
                            </el-avatar>
                                <span>{{ item.name }}</span>
                             <i class="iconfont icon-more" style="font-size: 20px;"></i>
                                  </div>
                               </div>
                            </div>
                            <div class="tool">    
      <el-button type="primary" :icon="Edit" color="#4d5b2f"/>
      <el-button type="primary" :icon="Share" color="#4d5b2f"/>
      <el-button type="primary" :icon="Delete" color="#4d5b2f"/>
      <el-button type="primary" :icon="Search"color="#4d5b2f">Search</el-button>
      <el-button type="primary"color="#4d5b2f" @click="goToNav">
       申报 <el-icon class="el-icon--right"><Upload /></el-icon>
      </el-button>
    </div>
                          </el-scrollbar>
                          
    </el-col>
  </el-row>
</template>

<style lang="scss" scoped>
.el-row:nth-of-type(1) {
  justify-content: center;
  height: 100px;
  border-radius: 6px;
  background-color: #303133;
  margin: 5px 10px;
  text-align: center;
  font-size: 18px;
  box-shadow: 5px 5px 5px grey;
  .el-col{
    display: flex;
    align-items: center;
    justify-content: space-around;
    width: 100%;
    el-button {
    flex: 1;
    height: 100%;

  }
  i {
    flex: auto;
    color: aliceblue;
     text-align: center;
  }
  }
}
.demo {
  padding: 0 5px;
  height: 75%;
  box-sizing: border-box;
  justify-content: center;
  .el-col {
    border-radius: 4px;
    background-color: #303133;
    margin: 0 10px;
    border-radius: 6px;
    box-shadow: 10px 10px 10px grey;
    .tool{
      display: flex;
      height: 200px;
      justify-content: flex-end;
       align-items: flex-end; 
    }
  }
}
.el-row {
  margin-bottom: 20px;
}
.el-row:last-child {
  margin-bottom: 0;
}
.el-col {
  border-radius: 4px;
}

.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.emp-box {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            gap: 20px;
             @include font_color('text-100');

            h3 {
               color: aliceblue;
            }

            .emp {
               padding: 5px;
               border-radius: 8px;
               border: 2px solid;
               @include border_color('text-200');
               user-select: none;
               .emp-item{
                  display: flex;
                  align-items: center;
                  justify-content: space-between;

               }
            }
         }
</style>

